package com.ranjan.cis.dao;

import java.util.List;

import com.ranjan.cis.dto.StudentBean;

public interface StudentDaoInter {
	public List<StudentBean> getStudents();
	public StudentBean initiateCreateStudent();
	public void createStudent(StudentBean studentBean);
	public StudentBean initiateUpdateStudent(int id);
	public void updateStudent(StudentBean studentBean);
	public void deleteStudent(int id);
}
