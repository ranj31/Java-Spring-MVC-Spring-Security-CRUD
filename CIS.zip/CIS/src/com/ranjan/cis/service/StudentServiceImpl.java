package com.ranjan.cis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ranjan.cis.dao.StudentDao;
import com.ranjan.cis.dto.StudentBean;

/**
 * @author Ranjan Chaudhary
 */

@Service
public class StudentServiceImpl implements StudentServiceInter {

	@Autowired
	StudentDao studentDao;

	@Override
	public StudentBean initiateCreateStudent() {
		return studentDao.initiateCreateStudent();
	}

	@Override
	public void createStudent(StudentBean studentBean) {
		 studentDao.createStudent(studentBean);
	}

	@Override
	public List<StudentBean> getStudents() {
		return studentDao.getStudents();
	}

	@Override
	public StudentBean initiateUpdateStudent(int id) {
		return studentDao.initiateUpdateStudent(id);
	}

	@Override
	public void updateStudent(StudentBean studentBean) {
		studentDao.updateStudent(studentBean);
	}

	@Override
	public void deleteStudent(int id) {
		studentDao.deleteStudent(id);
	}
}
