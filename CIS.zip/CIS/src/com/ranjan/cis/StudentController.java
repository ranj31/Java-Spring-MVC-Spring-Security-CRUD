package com.ranjan.cis;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;

import com.ranjan.cis.dto.StudentBean;
import com.ranjan.cis.service.StudentServiceInter;


/**
 * @author Ranjan Chaudhary
 */

@Controller
public class StudentController {

	@Autowired
	StudentServiceInter studentService;
	
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView executeSecurity(ModelMap model, Principal principal, HttpServletRequest request) {
		String userName = principal.getName();
		model.addAttribute("message", "Hi " + userName + ", Welcome to 'iCom site'");
		return new ModelAndView("viewContact", "studentForm", studentService.getStudents());
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout() {
		return "logoutpage";
	}

	@RequestMapping(value = "/getStudents", method = RequestMethod.GET)
	public ModelAndView getStudents() {
		return new ModelAndView("viewContact", "studentForm", studentService.getStudents());
	}

	@RequestMapping(value = "/initiateCreateStudent", method = RequestMethod.GET)
	public ModelAndView initiateCreateStudent() {
		return new ModelAndView("newContact", "command", studentService.initiateCreateStudent());
	}

	@RequestMapping(value = "/createStudent", method = RequestMethod.POST)
	public String createStudent(@ModelAttribute("SpringMVCPro") StudentBean student, ModelMap model) {
		studentService.createStudent(student);
		return "redirect:/index";
	}

	@RequestMapping("/initiateUpdateStudent")
	public ModelAndView initiateUpdateStudent(@RequestParam("id") int id) {
		return new ModelAndView("editContact", "command", studentService.initiateUpdateStudent(id));
	}

	@RequestMapping(value = "/updateStudent", method = RequestMethod.POST)
	public String updateStudent(@ModelAttribute("SpringMVCPro") StudentBean student, ModelMap model) {
		studentService.updateStudent(student);
		return "redirect:/index";
	}

	@RequestMapping("/deleteStudent")
	public String deleteStudent(@RequestParam("id") int id) {
		studentService.deleteStudent(id);
		return "redirect:/index";
	}
	
	@RequestMapping(value = "/loginFail", method = RequestMethod.GET)
	public String loginFail(HttpServletResponse response, HttpServletRequest request, ModelMap model) {
		model.addAttribute("blankuser", "true");
		return "login";
	}
	
	@RequestMapping(value = "/accessdenied", method = RequestMethod.GET)
	public String accessDenied(ModelMap model, Principal principal) {
		String username = principal.getName();
		model.addAttribute("message", "Sorry " + username + " You don't have privileges to do this action!!!");
		return "accessdenied";
	}
}
