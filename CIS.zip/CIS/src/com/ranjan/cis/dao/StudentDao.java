package com.ranjan.cis.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ranjan.cis.dto.StudentBean;

/**
 * @author Ranjan Chaudhary
 * This class worked as a repository of contact information of a student.
 * Here we are using List to store all the contacts of students.
 *
 */
@Repository
public class StudentDao implements StudentDaoInter {

	public List<StudentBean> studentContactList = new ArrayList<StudentBean>();
	
	public StudentDao() {
		studentContactList.add(new StudentBean(1, "Ranjan","Chaudhary","ranjancha@gmail.com","active"));
		studentContactList.add(new StudentBean(2, "Gaurav","Chavan","gaurav@gmail.com","active"));
		studentContactList.add(new StudentBean(3, "Neeraj","Saarathi","neeraj@gmail.com","active"));
		studentContactList.add(new StudentBean(4, "Ashish","Kumar","ashish@gmail.com","active"));
	}
	
	public List<StudentBean> getStudents() {
		return this.studentContactList;
	}

	
	/**
     * Returns object of StudentBean to initiate create of new student contact.
     * @return - StudentBean
     */
		
	@Override
	public StudentBean initiateCreateStudent() {
		int autoId = 0;
		if(studentContactList.size()>0){
			StudentBean student = (StudentBean) studentContactList.get(studentContactList.size()-1);
			autoId = student.getId()+1;
		}else {
			autoId = autoId +1;
		}
		return new StudentBean(autoId, "", "", "", "");
	}

	/**
     * This method creates new entry of student contact in List.
     */
	@Override
	public void createStudent(StudentBean studentBean) {
		studentContactList.add(studentBean);
	}

	/**
     * Returns object of StudentBean to initiate update of existing student contact.
     * @return - StudentBean
     */
	@Override
	public StudentBean initiateUpdateStudent(int id) {
		int listid = 0;
		StudentBean s;
		for (StudentBean element : studentContactList) {
			if (element.getId() == id) {
				listid = studentContactList.indexOf(element);
				break;
			}
		}
		s = (StudentBean) studentContactList.get(listid);
		return new StudentBean(s.getId(), s.getFirstName(), s.getLastName(),s.getEmailId(),s.getStatus());
	}
	
	/**
     * This method update existing student contact in List.
     */
	
	@Override
	public void updateStudent(StudentBean studentBean) {
		int listid = 0;
		//StudentBean s;
		for (StudentBean element : studentContactList) {
			if (element.getId() == studentBean.getId()) {
				listid = studentContactList.indexOf(element);
				break;
			}
		}
		studentContactList.set(listid, studentBean);
	}
	
	/**
     * This method delete existing student contact in List.
     */
	public void deleteStudent(int id) {
		int listid = 0;
		for (StudentBean element : studentContactList) {
			if (element.getId() == id) {
				listid = studentContactList.indexOf(element);
				break;
			}
		}
		studentContactList.remove(listid);
	}
}
